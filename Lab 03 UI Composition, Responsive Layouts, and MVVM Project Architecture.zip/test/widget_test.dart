import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:first_flutter_app/main.dart';

void setPortraitSize(WidgetTester tester) {
  tester.view.physicalSize = const Size(400, 900);
  tester.view.devicePixelRatio = 1;
  addTearDown(tester.view.resetPhysicalSize);
  addTearDown(tester.view.resetDevicePixelRatio);
}

void main() {
  testWidgets('shows cruise details and booking preferences', (
    WidgetTester tester,
  ) async {
    setPortraitSize(tester);

    await tester.pumpWidget(const RajangCruiseApp());

    expect(find.text('Rajang River Cruise'), findsOneWidget);
    expect(find.text('Sibu, Sarawak, Malaysia'), findsOneWidget);
    expect(find.text('Plan your cruise'), findsOneWidget);
    expect(find.text('Private River Cruise'), findsOneWidget);
    expect(find.text('CALL'), findsOneWidget);
    expect(find.text('ROUTE'), findsOneWidget);
    expect(find.text('SHARE'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('DropdownButton changes the cruise package', (
    WidgetTester tester,
  ) async {
    setPortraitSize(tester);

    await tester.pumpWidget(const RajangCruiseApp());
    await tester.ensureVisible(
      find.byKey(const ValueKey('cruise-package-dropdown')),
    );
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('cruise-package-dropdown')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Sunset Cruise').last);
    await tester.pumpAndSettle();

    expect(find.text('Sunset Cruise'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('rating and theme controls update interactively', (
    WidgetTester tester,
  ) async {
    setPortraitSize(tester);

    await tester.pumpWidget(const RajangCruiseApp());
    expect(find.text('41'), findsOneWidget);
    expect(
      Theme.of(tester.element(find.byType(Scaffold))).brightness,
      Brightness.light,
    );
    await tester.tap(find.byTooltip('Rate cruise'));
    await tester.pumpAndSettle();
    expect(find.text('42'), findsOneWidget);

    await tester.ensureVisible(find.byType(SwitchListTile));
    await tester.pumpAndSettle();
    await tester.tap(find.byType(SwitchListTile));
    await tester.pumpAndSettle();
    expect(find.byType(SwitchListTile), findsOneWidget);
    expect(
      Theme.of(tester.element(find.byType(Scaffold))).brightness,
      Brightness.dark,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets('visit date control opens a date picker', (
    WidgetTester tester,
  ) async {
    setPortraitSize(tester);

    await tester.pumpWidget(const RajangCruiseApp());
    await tester.ensureVisible(find.text('Visit date'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Visit date'));
    await tester.pumpAndSettle();

    expect(find.byType(CalendarDatePicker), findsOneWidget);
    await tester.tap(find.byType(TextButton).first);
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
  });

  testWidgets('adapts between portrait and landscape layouts', (
    WidgetTester tester,
  ) async {
    setPortraitSize(tester);
    await tester.pumpWidget(const RajangCruiseApp());
    expect(find.text('Rajang River Cruise'), findsOneWidget);
    expect(tester.takeException(), isNull);

    tester.view.physicalSize = const Size(900, 400);
    await tester.pumpAndSettle();

    expect(find.text('Rajang River Cruise'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
