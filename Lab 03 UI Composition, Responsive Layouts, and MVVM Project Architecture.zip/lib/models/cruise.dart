class Cruise {
  const Cruise({
    required this.name,
    required this.location,
    required this.subtitle,
    required this.description,
    required this.packages,
  });

  final String name;
  final String location;
  final String subtitle;
  final String description;
  final List<String> packages;

  static const Cruise rajangRiver = Cruise(
    name: 'Rajang River Cruise',
    location: 'Sibu, Sarawak, Malaysia',
    subtitle: 'Discover the longest river in Malaysia',
    description:
        'Discover the beauty and heritage of the Rajang River on a relaxing '
        'cruise from Sibu. Take in riverside villages, lush tropical scenery '
        'and the everyday life of communities along the river. Choose the '
        'cruise that fits your day and enjoy a memorable journey through the '
        'heart of Sarawak.',
    packages: [
      'Private River Cruise',
      'Sunset Cruise',
      'Sunrise Cruise',
      'Rural Cruise',
      'SMI Park Cruise',
    ],
  );
}
