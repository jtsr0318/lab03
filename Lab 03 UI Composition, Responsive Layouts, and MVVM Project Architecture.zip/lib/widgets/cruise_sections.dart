import 'package:flutter/material.dart';

import '../viewmodels/cruise_view_model.dart';

class ImageSection extends StatelessWidget {
  const ImageSection({super.key});

  static const String imageUrl =
      'https://images.unsplash.com/photo-1500375592092-40eb2168fd21'
      '?auto=format&fit=crop&w=1600&q=85';

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isWide = constraints.maxWidth > 700;
        return SizedBox(
          height: isWide ? double.infinity : 270,
          width: double.infinity,
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.network(
                imageUrl,
                fit: BoxFit.cover,
                semanticLabel: 'Tropical river landscape',
                loadingBuilder: (context, child, progress) => progress == null
                    ? child
                    : const _RiverImageFallback(showProgress: true),
                errorBuilder: (context, error, stackTrace) =>
                    const _RiverImageFallback(),
              ),
              const DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Color(0x77000000)],
                  ),
                ),
              ),
              if (!isWide)
                const Positioned(
                  left: 20,
                  bottom: 20,
                  child: Text(
                    'RAJANG RIVER · SARAWAK',
                    style: TextStyle(
                      color: Colors.white,
                      letterSpacing: 1.4,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _RiverImageFallback extends StatelessWidget {
  const _RiverImageFallback({this.showProgress = false});

  final bool showProgress;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF8FC8BE), Color(0xFF226D62), Color(0xFF173F3A)],
        ),
      ),
      child: Center(
        child: showProgress
            ? const CircularProgressIndicator(color: Colors.white)
            : const Icon(
                Icons.directions_boat_filled,
                size: 72,
                color: Colors.white70,
              ),
      ),
    );
  }
}

class TitleSection extends StatelessWidget {
  const TitleSection({super.key, required this.viewModel});

  final CruiseViewModel viewModel;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(top: 22, bottom: 16),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  viewModel.cruise.name,
                  style: theme.textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  viewModel.cruise.location,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  viewModel.cruise.subtitle,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Column(
            children: [
              IconButton(
                tooltip: viewModel.hasRated ? 'Remove rating' : 'Rate cruise',
                onPressed: viewModel.toggleRating,
                icon: Icon(
                  viewModel.hasRated ? Icons.star : Icons.star_border,
                  color: theme.colorScheme.primary,
                ),
              ),
              Text('${viewModel.ratingCount}', semanticsLabel: 'ratings'),
            ],
          ),
        ],
      ),
    );
  }
}

class ButtonSection extends StatelessWidget {
  const ButtonSection({super.key, required this.onAction});

  final ValueChanged<String> onAction;

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.primary;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _ActionButton(
            icon: Icons.call_outlined,
            label: 'CALL',
            color: color,
            onTap: () => onAction('Call cruise operator'),
          ),
          _ActionButton(
            icon: Icons.near_me_outlined,
            label: 'ROUTE',
            color: color,
            onTap: () => onAction('Route to Sibu, Sarawak'),
          ),
          _ActionButton(
            icon: Icons.share_outlined,
            label: 'SHARE',
            color: color,
            onTap: () => onAction('Share Rajang River Cruise'),
          ),
        ],
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  const _ActionButton({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Semantics(
        button: true,
        label: label,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Column(
              children: [
                Icon(icon, color: color, size: 25),
                const SizedBox(height: 6),
                Text(
                  label,
                  style: TextStyle(
                    color: color,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class TextSection extends StatelessWidget {
  const TextSection({super.key, required this.description});

  final String description;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 12, bottom: 20),
      child: Text(
        description,
        style: Theme.of(context).textTheme.bodyLarge?.copyWith(height: 1.55),
      ),
    );
  }
}

class PreferenceSection extends StatelessWidget {
  const PreferenceSection({super.key, required this.viewModel});

  final CruiseViewModel viewModel;

  @override
  Widget build(BuildContext context) {
    final dateText = MaterialLocalizations.of(context)
        .formatMediumDate(viewModel.visitDate);
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Plan your cruise',
              style: Theme.of(context).textTheme.titleMedium
                  ?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.calendar_month_outlined),
              title: const Text('Visit date'),
              subtitle: Text(dateText),
              trailing: const Icon(Icons.edit_calendar_outlined),
              onTap: () async {
                final today = DateUtils.dateOnly(DateTime.now());
                final selected = await showDatePicker(
                  context: context,
                  initialDate: viewModel.visitDate.isBefore(today)
                      ? today
                      : viewModel.visitDate,
                  firstDate: today,
                  lastDate: DateTime(today.year + 2, today.month, today.day),
                );
                if (selected != null) viewModel.selectVisitDate(selected);
              },
            ),
            const Divider(height: 1),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Row(
                children: [
                  const Icon(Icons.directions_boat_outlined),
                  const SizedBox(width: 16),
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      key: const ValueKey('cruise-package-dropdown'),
                      initialValue: viewModel.selectedPackage,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        labelText: 'Cruise package',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                      items: viewModel.cruise.packages
                          .map(
                            (package) => DropdownMenuItem(
                              value: package,
                              child: Text(
                                package,
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                            ),
                          )
                          .toList(),
                      onChanged: (package) {
                        if (package != null) viewModel.selectPackage(package);
                      },
                    ),
                  ),
                ],
              ),
            ),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: const Text('Dark theme'),
              secondary: const Icon(Icons.dark_mode_outlined),
              value: viewModel.isDarkMode,
              onChanged: viewModel.toggleTheme,
            ),
          ],
        ),
      ),
    );
  }
}
