import 'package:flutter/material.dart';

import 'models/cruise.dart';
import 'viewmodels/cruise_view_model.dart';
import 'views/cruise_details_screen.dart';

void main() => runApp(const RajangCruiseApp());

class RajangCruiseApp extends StatefulWidget {
  const RajangCruiseApp({super.key});

  @override
  State<RajangCruiseApp> createState() => _RajangCruiseAppState();
}

class _RajangCruiseAppState extends State<RajangCruiseApp> {
  late final CruiseViewModel _viewModel = CruiseViewModel(Cruise.rajangRiver);

  @override
  void dispose() {
    _viewModel.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: _viewModel,
    builder: (context, _) => MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Rajang River Cruise',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF167D74),
          brightness: Brightness.light,
        ),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF62C6B4),
          brightness: Brightness.dark,
        ),
      ),
      themeMode: _viewModel.isDarkMode ? ThemeMode.dark : ThemeMode.light,
      home: CruiseDetailsScreen(viewModel: _viewModel),
    ),
  );
}
