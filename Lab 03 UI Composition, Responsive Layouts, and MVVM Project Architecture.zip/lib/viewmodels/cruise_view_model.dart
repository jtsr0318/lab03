import 'package:flutter/material.dart';

import '../models/cruise.dart';

class CruiseViewModel extends ChangeNotifier {
  CruiseViewModel(this.cruise)
    : _selectedPackage = cruise.packages.first,
      _visitDate = DateUtils.dateOnly(DateTime.now());

  final Cruise cruise;
  String _selectedPackage;
  DateTime _visitDate;
  bool _isDarkMode = false;
  int _ratingCount = 41;
  bool _hasRated = false;

  String get selectedPackage => _selectedPackage;
  DateTime get visitDate => _visitDate;
  bool get isDarkMode => _isDarkMode;
  int get ratingCount => _ratingCount;
  bool get hasRated => _hasRated;

  void selectPackage(String package) {
    if (!cruise.packages.contains(package) || package == _selectedPackage) {
      return;
    }
    _selectedPackage = package;
    notifyListeners();
  }

  void selectVisitDate(DateTime date) {
    _visitDate = DateUtils.dateOnly(date);
    notifyListeners();
  }

  void toggleTheme(bool isDark) {
    if (_isDarkMode == isDark) return;
    _isDarkMode = isDark;
    notifyListeners();
  }

  void toggleRating() {
    _hasRated = !_hasRated;
    _ratingCount += _hasRated ? 1 : -1;
    notifyListeners();
  }
}
