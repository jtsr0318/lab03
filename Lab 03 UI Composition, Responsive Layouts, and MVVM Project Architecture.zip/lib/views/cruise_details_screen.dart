import 'package:flutter/material.dart';

import '../viewmodels/cruise_view_model.dart';
import '../widgets/cruise_sections.dart';

class CruiseDetailsScreen extends StatelessWidget {
  const CruiseDetailsScreen({super.key, required this.viewModel});

  final CruiseViewModel viewModel;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('River cruise'),
        actions: [
          IconButton(
            tooltip: 'Share cruise',
            onPressed: () => _showMessage(context, 'Share Rajang River Cruise'),
            icon: const Icon(Icons.ios_share_outlined),
          ),
        ],
      ),
      body: OrientationBuilder(
        builder: (context, orientation) {
          if (orientation == Orientation.landscape) {
            return Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Expanded(flex: 5, child: ImageSection()),
                Expanded(
                  flex: 6,
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
                    children: _details(context),
                  ),
                ),
              ],
            );
          }
          return ListView(
            padding: const EdgeInsets.only(bottom: 24),
            children: [
              const ImageSection(),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: _details(context),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  List<Widget> _details(BuildContext context) => [
    TitleSection(viewModel: viewModel),
    ButtonSection(onAction: (action) => _showMessage(context, action)),
    TextSection(description: viewModel.cruise.description),
    PreferenceSection(viewModel: viewModel),
  ];

  void _showMessage(BuildContext context, String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }
}
